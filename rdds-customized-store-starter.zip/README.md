# RDDS Customized Store

Separate Vite + React storefront for RDDS Customized.

## Run locally
1. Install Node.js 20+
2. `npm install`
3. `npm run dev`

## Current starter features
- Responsive luxury black/gold storefront
- Product search and category selection
- Local cart interactions
- Custom-order brief that opens WhatsApp
- Homepage sections based on the approved concept

## Next integration phase
- Connect the dedicated RDDS Customized Supabase project
- Load products/categories from database
- Admin authentication and product/order management
- Customer checkout, order tracking, image uploads and live product customizer

No credentials or Supabase project values are included yet.
